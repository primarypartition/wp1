CREATE DATABASE  IF NOT EXISTS `wp_pro1` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `wp_pro1`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: wp_pro1
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_wc_product_meta_lookup`
--

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_product_meta_lookup`
--

LOCK TABLES `wp_wc_product_meta_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_product_meta_lookup` DISABLE KEYS */;
INSERT INTO `wp_wc_product_meta_lookup` VALUES (10,'Towel-123',0,0,5.0000,22.0000,0,NULL,'instock',0,0.00,0,'taxable',''),(13,'SPA-03',0,0,15.0000,15.0000,0,NULL,'instock',0,0.00,0,'taxable',''),(18,'',0,0,20.0000,20.0000,0,12,'instock',0,0.00,0,'taxable',''),(22,'',0,0,11.0000,11.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(23,'',0,0,22.0000,22.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(29,'',0,0,11.0000,11.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(30,'',0,0,5.0000,5.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(31,'',0,0,22.0000,22.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(32,'',0,0,11.0000,11.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(33,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(34,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(35,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(36,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(37,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(38,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(39,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(40,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(41,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(42,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(43,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(44,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(45,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(46,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(47,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(48,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(49,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(50,'',0,0,0.0000,0.0000,0,NULL,'instock',0,0.00,0,'taxable','parent'),(51,'',1,1,125.0000,125.0000,1,NULL,'instock',0,0.00,0,'taxable',''),(54,'ca',0,0,5.0000,10.0000,0,NULL,'instock',0,0.00,0,'taxable',''),(95,'SPA-03-1',0,0,15.0000,15.0000,0,NULL,'instock',0,0.00,0,'taxable',''),(96,'SPA-03-2',0,0,15.0000,15.0000,0,NULL,'instock',0,0.00,0,'taxable',''),(98,'',0,0,20.0000,20.0000,0,NULL,'instock',0,0.00,0,'taxable',''),(99,'',0,0,20.0000,20.0000,0,NULL,'instock',0,0.00,0,'taxable',''),(100,'SPA-03-3',0,0,15.0000,15.0000,0,NULL,'instock',0,0.00,0,'taxable','');
/*!40000 ALTER TABLE `wp_wc_product_meta_lookup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-15 13:33:49
