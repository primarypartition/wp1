CREATE DATABASE  IF NOT EXISTS `wp_pro1` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `wp_pro1`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: wp_pro1
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES (2,2,'product_type','',0,8),(3,3,'product_type','',0,1),(4,4,'product_type','',0,1),(5,5,'product_type','',0,0),(6,6,'product_visibility','',0,0),(7,7,'product_visibility','',0,0),(8,8,'product_visibility','',0,4),(9,9,'product_visibility','',0,0),(10,10,'product_visibility','',0,0),(11,11,'product_visibility','',0,0),(12,12,'product_visibility','',0,0),(13,13,'product_visibility','',0,0),(14,14,'product_visibility','',0,0),(15,15,'product_cat','',0,0),(16,16,'product_cat','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum elementum arcu ut velit molestie posuere. Pellentesque sed scelerisque arcu, a venenatis justo. Integer fringilla, massa id tincidunt sagittis, arcu augue pulvinar erat, in ullamcorper mauris massa in ipsum. Vivamus in justo nec est porttitor faucibus. Curabitur nec ultricies ligula. Integer ut mauris augue. Donec quis eros dignissim, rhoncus odio at, ornare velit.',0,4),(17,17,'product_tag','',0,2),(18,18,'product_cat','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum elementum arcu ut velit molestie posuere. Pellentesque sed scelerisque arcu, a venenatis justo. Integer fringilla, massa id tincidunt sagittis, arcu augue pulvinar erat, in ullamcorper mauris massa in ipsum. Vivamus in justo nec est porttitor faucibus. Curabitur nec ultricies ligula. Integer ut mauris augue. Donec quis eros dignissim, rhoncus odio at, ornare velit.',0,4),(19,19,'product_tag','',0,4),(20,20,'product_tag','',0,3),(21,21,'pa_size','',0,1),(22,22,'pa_size','',0,1),(23,23,'pa_size','',0,1),(24,24,'product_cat','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum elementum arcu ut velit molestie posuere. Pellentesque sed scelerisque arcu, a venenatis justo. Integer fringilla, massa id tincidunt sagittis, arcu augue pulvinar erat, in ullamcorper mauris massa in ipsum. Vivamus in justo nec est porttitor faucibus. Curabitur nec ultricies ligula. Integer ut mauris augue. Donec quis eros dignissim, rhoncus odio at, ornare velit.',0,1),(25,25,'product_tag','',0,1),(26,26,'product_cat','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum elementum arcu ut velit molestie posuere. Pellentesque sed scelerisque arcu, a venenatis justo. Integer fringilla, massa id tincidunt sagittis, arcu augue pulvinar erat, in ullamcorper mauris massa in ipsum. Vivamus in justo nec est porttitor faucibus. Curabitur nec ultricies ligula. Integer ut mauris augue. Donec quis eros dignissim, rhoncus odio at, ornare velit.',0,1),(27,27,'product_tag','',0,1),(28,28,'product_tag','',0,1),(29,29,'category','',0,1),(30,30,'product_shipping_class','Insurance',0,4),(31,31,'nav_menu','',0,8),(32,32,'nav_menu','',0,3),(33,33,'nav_menu','',0,4),(34,34,'category','',0,1),(35,35,'category','',0,1);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-15 13:33:47
